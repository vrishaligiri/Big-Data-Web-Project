var express = require('express');
var router = express.Router();
var Product = require('../models/product');


var elasticsearch = require('elasticsearch');
var client = new elasticsearch.Client();

/* GET home page. */
router.get('/', function(req, res, next) {
  Product.find(function(err, docs){
      var productChunks = [];
      var chunkSize = 3;
      for(var i = 0; i < docs.length; i += chunkSize) {
        productChunks.push(docs.slice(i, i + chunkSize));
      }
      res.render('index', { title: 'Online Recipes', products: productChunks });
  });
});

//router.get('/searchproducts', function(req, res) {
   // console.log('Here!!!!');
//});
router.get('/searchproducts',function(request,response,next){
    var userQuery = request.param('query');
    console.log(userQuery);
    //var userId = request.session.userId;
    //console.log(request);
    var searchParams = {
        index: 'shopping',
        type: 'product',
        body: {
            query: {

                match: {
                    // match the query against all of
                    // the fields in the posts index
                    name: userQuery
                }

            }
        }
    };


    client.search(searchParams, function (err, res) {
        if (err) {
            // handle error
            throw err;
        }
        //console.log(res);
        var results = res.hits.hits.map(function(i){
            return i['_source'];
        });
        /*var results = res['hits']['hits'].map(function(i){
         return i['_source'];
         });*/
        //console.log(results);
        //var docs = res.hits.hits._source;
        //console.log(docs);
        var productChunks = [];
        var chunkSize = 3;
        for(var i = 0; i < results.length;i += chunkSize){
            productChunks.push(results.slice(i,i+chunkSize));

            console.log(productChunks);
        }
        response.render('index', {
            products: productChunks
        });
    });
});

module.exports = router;


