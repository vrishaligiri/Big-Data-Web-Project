var mongoose = require('mongoose');
var Schema  = mongoose.Schema;

var Schema = new Schema ({
    /*imagepath: {type: String, required: true},
    title: {type: String, required: true},
    description: {type: String, required: true},
    price: {type: Number, required: true},*/
    Recipe_id: {type: Number, required: true},
    category: {type: String, required: true},
    name: {type: String, required: true},
    detail: {
        detail_id: {type: Number, required: true},
        rating: {type: Number, required: true},
        img:{
            src: {type: String, required: true}
        },
    },
    attr: {
        imgs: {
            src: {type: String, required: true},
            height: {type: Number, required: true},
            width: {type: Number, required: true}
        },
    },
    cooking_time: {type: String, required: true},
    serves: {type: String, required: true},
    approx_cost: {type: String, required: true},
    directions: {type: String, required: true},
    ingredients: {type: String, required: true}
});

module.exports = mongoose.model('Product', Schema);